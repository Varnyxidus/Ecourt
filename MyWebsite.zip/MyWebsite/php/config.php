<?php
    $con = mysqli_connect("localhost", "root", "", "Ecourt") or die("Couldn't connect to database");
?>